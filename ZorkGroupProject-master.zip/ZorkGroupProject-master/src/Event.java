/**
 * Created by Michael Timpson on 11/8/16.
 * @author Michael
 * @return
 */
class Event {

    /**
     *
     * @param num
     * Construtor for event class
     */
    Event(int num) {

    }

    /**
     *
     * @param str
     * Constructor for event class
     */
    Event(String str) {

    }

    /**
     *
     * @param bol
     * Constructor for event class
     */
    Event(Boolean bol) {

    }

    /**
     *
     * @param score
     * @return
     *
     */
    int score(int score) {

    }

    /**
     *
     * @param health
     * @return
     */
    int wound(int health) {

    }

    /**
     *
     * @param death
     * @return
     */
    String die(boolean death) {

    }

    /**
     *
     * @param win
     * @return
     */
    String win(boolean win) {

    }

    /**
     *
     * @param item
     */
    void disappear(Item item) {

    }

    /**
     *
     * @param item
     * @return
     */
    Item transform(Item item) {

    }

    /**
     *
     * @return
     */
    Room teleport() {

    }

}
