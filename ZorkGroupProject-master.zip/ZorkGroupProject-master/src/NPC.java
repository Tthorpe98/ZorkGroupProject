import java.util.ArrayList;

/**
 * Created by Michael on 11/8/16.
 * @author Michael Timpson
 * Class creates a Non-Player-Character and adds methods
 * to utilize the NPC
 */
class NPC {

    private boolean enemy;
    private String name;
    private Room location;
    private int health;
    private ArrayList<Item> inventory;

    /**
     *
     * @param room
     * @param name
     * @param enemy
     * @param health
     *
     * Constructs the Non-Player-Character
     */
    public NPC(Room room, String name, boolean enemy, int health) {

    }

    /**
     *
     * @return enemy
     * Returns true or false if enemy
     */
    public boolean getEnemy() {

    }

    /**
     *
     * @param enemy
     * Sets enemy to true or false
     */
    public void setEnemy(boolean enemy) {

    }

    /**
     *
     * @param enemy
     * Set's name of enemy
     */
    public void setName(boolean enemy) {

    }

    /**
     *
     * @return name
     * Get the name of the enemy.
     */
    public String getName() {

    }

    /**
     *
     * @param location
     * Set location of the enemy
     */
    public void setLocation(Room location) {

    }

    /**
     *
     * @return health
     * Returns the health of the enemy.
     */
    public int getHealth() {

    }

    /**
     *
     * @param health
     * Set's the health of the enemy.
     */
    public void setHealth(int health) {

    }

    /**
     *
     * @param item
     * @return
     * Boolean if item has been used or not.
     */
    public boolean useItem(Item item) {

    }

}
