/**
 * Created by Michael Timpson on 11/8/16.
 * @author Michael Timpson
 * Attack command that extends the Command interface.
 */
class AttackCommand extends Command {

    /**
     *
     */
    AttackCommand() {

    }

    /**
     *
     * @return
     */
    public String execute() {

    }
}

