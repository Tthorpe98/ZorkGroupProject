
abstract class Command {

    abstract String execute();

}
